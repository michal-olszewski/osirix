//
//  url.h
//  OsiriX_Lion
//
//  Created by Alex Bettarini on 22 Nov 2014.
//  Copyright (c) 2014 Osiri-LXIV Team. All rights reserved.
//

#ifndef URL_H_INCLUDED
#define URL_H_INCLUDED

// search for URLWithString
#define URL_OSIRIX_VIEWER           @"http://www.osirix-viewer.com"
#define URL_OSIRIX_WEB_PAGE         @"https://github.com/bettar/osirix"
#define URL_VENDOR                  @"http://pixmeo.pixmeo.com"
#define URL_EMAIL                   @"pixmeo@pixmeo.com"

#define URL_VENDOR_NOTICE           URL_VENDOR@"/products.html#OsiriXMD"
#define URL_VENDOR_USER_MANUAL      URL_VENDOR@"/products.html#OsiriXUserManual"

#define URL_OSIRIX_BANNER           URL_OSIRIX_VIEWER@"/OsiriXBanner.png"
#define URL_CLICK_BANNER            URL_OSIRIX_VIEWER@"/Banner.html"

#define URL_OSIRIX_DOC_SECURITY     URL_OSIRIX_VIEWER@"/Documentation/Guides/Security/index.html"
#define URL_OSIRIX_LEARNING         URL_OSIRIX_VIEWER@"/Learning.html"
#define URL_OSIRIX_UPDATE           URL_OSIRIX_VIEWER
#define URL_OSIRIX_UPDATE_CRASH     URL_OSIRIX_VIEWER@"/Downloads.html"
#define URL_OSIRIX_VERSION          URL_OSIRIX_VIEWER@"/versionLeopard.xml"
#define URL_OSIRIX_VERSION_OLD_OS   URL_OSIRIX_VIEWER@"/version.xml"
#define URL_OSIRIX_PLUGINS          URL_OSIRIX_VIEWER@"/Plugins.html"

////////////////////////////////////////////////////////////////////////////////
// We want our own Defaults plist saved in ~/Library/Preferences/
// Make sure it matches "Bundle Identifier" in Deployment-Info.plist

#define BUNDLE_IDENTIFIER_PREFIX    "com.github-bettar"
#define BUNDLE_IDENTIFIER           "com.github-bettar.osiri-lxiv"

////////////////////////////////////////////////////////////////////////////////
// This is the address of the plist containing the list of the available plugins.
// the alternative link will be used if the first one doesn't reply...

#define PLUGIN_LIST_URL                     @"http://www.osirix-viewer.com/osirix_plugins/plugins.plist"
#define PLUGIN_LIST_ALT_URL                 @"http://www.osirixviewer.com/osirix_plugins/plugins.plist"

#define PLUGIN_SUBMISSION_URL               @"http://www.osirix-viewer.com/osirix_plugins/submit_plugin/index.html"
#define PLUGIN_SUBMISSION_NO_MAIL_APP_URL   @"http://www.osirix-viewer.com/osirix_plugins/submit_plugin/index_no_mail_app.html"


#endif
